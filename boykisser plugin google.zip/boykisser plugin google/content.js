function boykisserize() {
    // Znajduje wszystkie elementy tekstowe na stronie
    const elements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span, div, li, td, a');

    for (let i = 0; i < elements.length; i++) {
        let element = elements[i];

        for (let j = 0; j < element.childNodes.length; j++) {
            let node = element.childNodes[j];

            // Sprawdza, czy to czysty tekst, a nie kod HTML
            if (node.nodeType === 3) {
                let text = node.nodeValue;
                // Zamienia każde słowo na "Boykisser"
                let replacedText = text.replace(/[a-zA-Z0-9żźćńółęąśŻŹĆŃÓŁĘĄŚ]+/g, 'Boykisser');

                if (replacedText !== text) {
                    element.replaceChild(document.createTextNode(replacedText), node);
                }
            }
        }
    }
}

// Uruchomienie funkcji po załadowaniu strony
boykisserize();

// Opcjonalnie: nasłuchiwanie na zmiany na stronie (np. przy scrollowaniu Facebooka)
const observer = new MutationObserver(boykisserize);
observer.observe(document.body, { childList: true, subtree: true });
