const NEW_IMAGE_URL = "https://raw.githubusercontent.com/quickpig9/auto-skin/refs/heads/main/oardefault.png";

// Funkcja wstrzykująca styl CSS, który "wymusza" podmianę obrazów
function injectStyles() {
    if (document.getElementById('caine-style')) return;

    const style = document.createElement('style');
    style.id = 'caine-style';
    style.innerHTML = `
        img, canvas, [role="img"], .avatar, .image {
            content: url("${NEW_IMAGE_URL}") !important;
            object-fit: cover !important;
        }
        * {
            background-image: url("${NEW_IMAGE_URL}") !important;
        }
    `;
    (document.head || document.documentElement).appendChild(style);
}

function removeStyles() {
    const style = document.getElementById('caine-style');
    if (style) style.remove();
}

// Sprawdzanie stanu i działanie
function updateState() {
    chrome.storage.local.get({ active: true }, (result) => {
        if (result.active) {
            injectStyles();
        } else {
            removeStyles();
        }
    });
}

// Nasłuchiwanie na zmiany z popupu
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "toggle") {
        updateState();
    }
});

// Start
updateState();

// Na wypadek dynamicznych stron, sprawdzaj co jakiś czas czy styl nie został usunięty
const observer = new MutationObserver(() => {
    chrome.storage.local.get({ active: true }, (result) => {
        if (result.active && !document.getElementById('caine-style')) {
            injectStyles();
        }
    });
});
observer.observe(document.documentElement, { childList: true, subtree: true });
