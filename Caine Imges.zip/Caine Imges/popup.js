const toggle = document.getElementById('toggleActive');
const statusText = document.getElementById('statusText');

// Pobierz obecny stan
chrome.storage.local.get({ active: true }, (result) => {
    toggle.checked = result.active;
    statusText.innerText = result.active ? "Włączone" : "Wyłączone";
});

// Zapisz stan przy zmianie
toggle.addEventListener('change', () => {
    const isActive = toggle.checked;
    chrome.storage.local.set({ active: isActive }, () => {
        statusText.innerText = isActive ? "Włączone" : "Wyłączone";
        
        // Wyślij sygnał do content.js na aktywnej karcie
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { action: "toggle" });
            }
        });
    });
});
